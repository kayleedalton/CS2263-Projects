﻿namespace KayleeDalton2263Ex3
{
    partial class Ex3
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.swapButton = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.digToLeft = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.reverseArrayButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.arrayInteger = new System.Windows.Forms.TextBox();
            this.s1 = new System.Windows.Forms.RichTextBox();
            this.s2 = new System.Windows.Forms.RichTextBox();
            this.isTextInText = new System.Windows.Forms.Button();
            this.isNInArray = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.integerN = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.avgASCII = new System.Windows.Forms.Button();
            this.avgAscLength = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.sumOfOdd = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // swapButton
            // 
            this.swapButton.Location = new System.Drawing.Point(23, 32);
            this.swapButton.Name = "swapButton";
            this.swapButton.Size = new System.Drawing.Size(75, 23);
            this.swapButton.TabIndex = 2;
            this.swapButton.Text = "Swap Em!";
            this.swapButton.UseVisualStyleBackColor = true;
            this.swapButton.Click += new System.EventHandler(this.button2_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 15;
            this.listBox1.Location = new System.Drawing.Point(118, 49);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(327, 64);
            this.listBox1.TabIndex = 3;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 61);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 23);
            this.textBox1.TabIndex = 4;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(12, 90);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 23);
            this.textBox2.TabIndex = 5;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // digToLeft
            // 
            this.digToLeft.Location = new System.Drawing.Point(23, 133);
            this.digToLeft.Name = "digToLeft";
            this.digToLeft.Size = new System.Drawing.Size(75, 23);
            this.digToLeft.TabIndex = 6;
            this.digToLeft.Text = "Enter #";
            this.digToLeft.UseVisualStyleBackColor = true;
            this.digToLeft.Click += new System.EventHandler(this.digToLeft_Click);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(104, 134);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 23);
            this.textBox3.TabIndex = 7;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 116);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(325, 15);
            this.label1.TabIndex = 8;
            this.label1.Text = "2. Enter a real number with a decimal to convert to numerals";
            // 
            // reverseArrayButton
            // 
            this.reverseArrayButton.Location = new System.Drawing.Point(23, 192);
            this.reverseArrayButton.Name = "reverseArrayButton";
            this.reverseArrayButton.Size = new System.Drawing.Size(75, 23);
            this.reverseArrayButton.TabIndex = 9;
            this.reverseArrayButton.Text = "GO";
            this.reverseArrayButton.UseVisualStyleBackColor = true;
            this.reverseArrayButton.Click += new System.EventHandler(this.reverseArrayButton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 174);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(370, 15);
            this.label2.TabIndex = 10;
            this.label2.Text = "3. and 4. Enter Integer and get random array reversed and printed out";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // arrayInteger
            // 
            this.arrayInteger.Location = new System.Drawing.Point(104, 192);
            this.arrayInteger.Name = "arrayInteger";
            this.arrayInteger.Size = new System.Drawing.Size(100, 23);
            this.arrayInteger.TabIndex = 11;
            // 
            // s1
            // 
            this.s1.Location = new System.Drawing.Point(493, 40);
            this.s1.Name = "s1";
            this.s1.Size = new System.Drawing.Size(100, 96);
            this.s1.TabIndex = 12;
            this.s1.Text = "";
            this.s1.TextChanged += new System.EventHandler(this.s1_TextChanged);
            // 
            // s2
            // 
            this.s2.Location = new System.Drawing.Point(726, 35);
            this.s2.Name = "s2";
            this.s2.Size = new System.Drawing.Size(100, 96);
            this.s2.TabIndex = 13;
            this.s2.Text = "";
            this.s2.TextChanged += new System.EventHandler(this.s2_TextChanged);
            // 
            // isTextInText
            // 
            this.isTextInText.Location = new System.Drawing.Point(618, 69);
            this.isTextInText.Name = "isTextInText";
            this.isTextInText.Size = new System.Drawing.Size(75, 23);
            this.isTextInText.TabIndex = 14;
            this.isTextInText.Text = "Is text in text?";
            this.isTextInText.UseVisualStyleBackColor = true;
            this.isTextInText.Click += new System.EventHandler(this.isTextInText_Click);
            // 
            // isNInArray
            // 
            this.isNInArray.Location = new System.Drawing.Point(23, 243);
            this.isNInArray.Name = "isNInArray";
            this.isNInArray.Size = new System.Drawing.Size(75, 23);
            this.isNInArray.TabIndex = 15;
            this.isNInArray.Text = "GO";
            this.isNInArray.UseVisualStyleBackColor = true;
            this.isNInArray.Click += new System.EventHandler(this.isNInArray_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 225);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(461, 15);
            this.label3.TabIndex = 16;
            this.label3.Text = "6. Click button to generate array that returns TRUE if entered integer is in rand" +
    "om array";
            // 
            // integerN
            // 
            this.integerN.Location = new System.Drawing.Point(118, 244);
            this.integerN.Name = "integerN";
            this.integerN.Size = new System.Drawing.Size(100, 23);
            this.integerN.TabIndex = 17;
            this.integerN.TextChanged += new System.EventHandler(this.integerN_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(451, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(402, 15);
            this.label4.TabIndex = 18;
            this.label4.Text = "5. Enter text into boxes and click button to see if they have text in common";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 14);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(194, 15);
            this.label5.TabIndex = 19;
            this.label5.Text = "1. Enter two numbers to swap them";
            // 
            // avgASCII
            // 
            this.avgASCII.Location = new System.Drawing.Point(23, 284);
            this.avgASCII.Name = "avgASCII";
            this.avgASCII.Size = new System.Drawing.Size(75, 23);
            this.avgASCII.TabIndex = 20;
            this.avgASCII.Text = "AvgASCII";
            this.avgASCII.UseVisualStyleBackColor = true;
            this.avgASCII.Click += new System.EventHandler(this.avgASCII_Click);
            // 
            // avgAscLength
            // 
            this.avgAscLength.Location = new System.Drawing.Point(118, 285);
            this.avgAscLength.Name = "avgAscLength";
            this.avgAscLength.Size = new System.Drawing.Size(100, 23);
            this.avgAscLength.TabIndex = 21;
            this.avgAscLength.TextChanged += new System.EventHandler(this.avgAscLength_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(23, 269);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(630, 15);
            this.label6.TabIndex = 22;
            this.label6.Text = "7. Randomly generate array of ascii characters of the length you enter into the b" +
    "ox, the average ascii value is displayed.";
            // 
            // sumOfOdd
            // 
            this.sumOfOdd.Location = new System.Drawing.Point(23, 333);
            this.sumOfOdd.Name = "sumOfOdd";
            this.sumOfOdd.Size = new System.Drawing.Size(75, 23);
            this.sumOfOdd.TabIndex = 23;
            this.sumOfOdd.Text = "TEST";
            this.sumOfOdd.UseVisualStyleBackColor = true;
            this.sumOfOdd.Click += new System.EventHandler(this.sumOfOdd_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(23, 315);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(567, 15);
            this.label7.TabIndex = 25;
            this.label7.Text = "Test recursive function that accepts a 1D array of integers a and returns the sum" +
    " of all the odd integers in a.\r\n";
            // 
            // Ex3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(868, 646);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.sumOfOdd);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.avgAscLength);
            this.Controls.Add(this.avgASCII);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.integerN);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.isNInArray);
            this.Controls.Add(this.isTextInText);
            this.Controls.Add(this.s2);
            this.Controls.Add(this.s1);
            this.Controls.Add(this.arrayInteger);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.reverseArrayButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.digToLeft);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.swapButton);
            this.Name = "Ex3";
            this.Text = "Ex3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Button swapButton;
        private ListBox listBox1;
        private TextBox textBox1;
        private TextBox textBox2;
        private Button digToLeft;
        private TextBox textBox3;
        private Label label1;
        private Button reverseArrayButton;
        private Label label2;
        private TextBox arrayInteger;
        private RichTextBox s1;
        private RichTextBox s2;
        private Button isTextInText;
        private Button isNInArray;
        private Label label3;
        private TextBox integerN;
        private Label label4;
        private Label label5;
        private Button avgASCII;
        private TextBox avgAscLength;
        private Label label6;
        private Button sumOfOdd;
        private Label label7;
    }
}