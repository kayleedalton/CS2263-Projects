﻿using System;
using System.Windows.Forms;

/*
    Author: Kaylee Dalton
    Professor: David Beard
    Date: February 15th, 2023
    
    This is an implementation of linked lists in C#
*/

//Used T as generic type since that seemed to be the standard
//I don't really understand why it has to be generic
//but in class you said to do that or else there would be bad consequences haha

namespace Project5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
 /* KD February 2023
  * Testing all the functions here.
  * Calls each function and displays to the message box a demonstration.
  * Uses random numbers to ensure the functions work for every number
*/

        private void button1_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            int value = random.Next(6);
            MessageBox.Show("First val is " + value);
            DoubleLinkedList<int> list = new DoubleLinkedList<int>(value);
            MessageBox.Show("Inserting values");
            value = random.Next(6);
            MessageBox.Show($"Inserting value {value} after current.");
            list.InsertAfterCurrent(value);
            value = random.Next(6);
            MessageBox.Show($"Inserting value {value} after current.");
            list.InsertAfterCurrent(value);
            value = random.Next(6);
            MessageBox.Show($"Inserting value {value} after last.");
            list.InsertAfterLast(value);
            value = random.Next(6);
            MessageBox.Show($"Inserting value {value} before first.");
            list.InsertBeforeFirst(value);
            MessageBox.Show($"Inserting value {value} after last.");
            list.InsertAfterLast(value);

            MessageBox.Show("Number of nodes in list: " + list.NumberOfNodesInList());

            MessageBox.Show("String content of list: " + list.GetDisplayString());

            MessageBox.Show("Deleting nodes");
            list.DeleteFirst();
            list.DeleteCurrent();
            list.DeleteLast();

            MessageBox.Show("Number of nodes in list: " + list.NumberOfNodesInList());

            MessageBox.Show("String content of list: " + list.GetDisplayString());

            MessageBox.Show("Getting a current node value: " + list.GetCurrentNode().value);

            value = random.Next(6);
            MessageBox.Show($"Searching for node with value {value} in the whole list.");
            DoubleLinkedListNode<int> foundNode = list.Find(value);
            if (foundNode != null)
            {
                MessageBox.Show("Node found: " + foundNode.value);
            }
            else
            {
                MessageBox.Show("Node not found.");
            }

            MessageBox.Show("Final string content of list: " + list.GetDisplayString());



        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
    /********************************
    KD February 2023
    This is an implementation of linked lists in C#
    This is the main definition of the DoubleLinkedList class
    ********************************/
    internal class DoubleLinkedList<T>
    {

        public DoubleLinkedListNode<T> firstNode = null;
        public DoubleLinkedListNode<T> lastNode = null;
        public DoubleLinkedListNode<T> currentNode = null;

        public int nodeNumber = 0;
        public DoubleLinkedList()
        {
        }

        // creates first node in list with firstValue
        public DoubleLinkedList(T firstValue)
        {
            firstNode = new DoubleLinkedListNode<T>(firstValue);
            lastNode = firstNode;
            currentNode = firstNode;
            nodeNumber = 1;
        }

        public DoubleLinkedListNode<T> GetCurrentNode()
        {
            return currentNode;
        }

        /*******************************
    * KD Feb2023 InsertFirst
    * Inserts a new node with the specified value at the beginning of the list.
    * *****************************/
        public void InsertFirst(T value)
        {
            DoubleLinkedListNode<T> newNode = new DoubleLinkedListNode<T>(value);

            if (firstNode == null)
            {
                firstNode = newNode;
                lastNode = firstNode;
                currentNode = firstNode;
            }
            else
            {

                newNode.next = firstNode;
                firstNode.previous = newNode;
                firstNode = newNode;
                currentNode = firstNode;
            }

            nodeNumber++;
        }
        /*******************************
    * KD Feb2023 InsertBeforeFirst
    * Inserts a new node with the specified value before the first node in the list.
    * *****************************/
        public void InsertBeforeFirst(T value)
        {
            if (firstNode == null)
            {
                InsertFirst(value);
                return;
            }

            DoubleLinkedListNode<T> newNode = new DoubleLinkedListNode<T>(value);
            newNode.next = firstNode;
            firstNode.previous = newNode;
            firstNode = newNode;
            nodeNumber++;
        }
        /*******************************
    * KD Feb2023 InsertAfterLast
    * Inserts a new node with the specified value after the last node in the list.
    * *****************************/
        public void InsertAfterLast(T value)
        {
            if (lastNode == null)
            {
                InsertFirst(value);
                return;
            }

            DoubleLinkedListNode<T> newNode = new DoubleLinkedListNode<T>(value);
            lastNode.next = newNode;
            newNode.previous = lastNode;
            lastNode = newNode;
            currentNode = lastNode;
            nodeNumber++;
        }
        /*******************************
    * KD Feb2023 InsertAfterCurrent
    * Inserts a new node with the specified value after the current node in the list.
    * *****************************/
        public void InsertAfterCurrent(T value)
        {
            if (currentNode == null)
            {
                InsertFirst(value);
                return;
            }

            DoubleLinkedListNode<T> newNode = new DoubleLinkedListNode<T>(value);
            newNode.next = currentNode.next;
            newNode.previous = currentNode;
            if (currentNode.next != null)
            {
                currentNode.next.previous = newNode;
            }
            currentNode.next = newNode;
            currentNode = newNode;
            if (lastNode == currentNode.previous)
            {
                lastNode = currentNode;
            }
            nodeNumber++;
        }
        /********************************

    KD Feb2023 NumberOfNodesInList
    Returns the number of nodes in the linked list
    *********************************/
        public int NumberOfNodesInList()
        {
            return nodeNumber;
        }

        /********************************
    KD Feb2023 DeleteFirst
    Deletes the first node in the linked list
    *********************************/
        public void DeleteFirst()
        {
            if (firstNode == null)
            {
                return;
            }

            if (firstNode.next == null)
            {
                firstNode = null;
                lastNode = null;
                currentNode = null;
            }
            else
            {
                firstNode = firstNode.next;
                firstNode.previous = null;
                currentNode = firstNode;
            }
            nodeNumber--;
        }
        /********************************

    KD Feb2023 DeleteLast
    Deletes the last node in the linked list
    *********************************/
        public void DeleteLast()
        {
            if (lastNode == null)
            {
                return;
            }

            if (lastNode.previous == null)
            {
                firstNode = null;
                lastNode = null;
                currentNode = null;
            }
            else
            {
                lastNode = lastNode.previous;
                lastNode.next = null;
                currentNode = lastNode;
            }
            nodeNumber--;
        }

        /********************************

    KD Feb2023 DeleteCurrent
    Deletes the current node in the linked list
    *********************************/
        public void DeleteCurrent()
        {
            if (currentNode == null)
            {
                return;
            }

            if (currentNode.previous == null)
            {
                DeleteFirst();
                return;
            }

            if (currentNode.next == null)
            {
                DeleteLast();
                return;
            }

            currentNode.previous.next = currentNode.next;
            currentNode.next.previous = currentNode.previous;
            currentNode = currentNode.next;
            nodeNumber--;
        }

        /********************************

    KD Feb2023 MoveToNext
    Moves the current node to the next node in the linked list
    *********************************/
        public void MoveToNext()
        {
            if (currentNode == null || currentNode.next == null)
            {
                return;
            }

            currentNode = currentNode.next;
        }

        /********************************

    KD Feb2023 MoveToPrevious
    Moves the current node to the previous node in the linked list
    *********************************/

        public void MoveToPrevious()
        {
            if (currentNode == null || currentNode.previous == null)
            {
                return;
            }

            currentNode = currentNode.previous;
        }
        /********************************

    KD Feb2023 Find/FindRecursive
        *finds a value in a list and tells you where it is,
        *or says it's not there. It checks each item in the list until it finds a match,
        *and keeps doing this until it finishes the list or finds the value.
    *********************************/

        public DoubleLinkedListNode<T> Find(T value)
        {
            return FindRecursive(firstNode, value);
        }

        private DoubleLinkedListNode<T> FindRecursive(DoubleLinkedListNode<T> node, T value)
        {
            if (node == null)
            {
                return null;
            }

            if (node.value.Equals(value))
            {
                return node;
            }

            return FindRecursive(node.next, value);
        }

        /********************************

    KD Feb2023 GetDisplayString/Recursive
    Returns a string representation of the linked list
    *********************************/
        public string GetDisplayString()
        {
            if (firstNode == null)
            {
                return "";
            }

            return GetDisplayStringRecursive(firstNode);
        }

        private string GetDisplayStringRecursive(DoubleLinkedListNode<T> node)
        {
            if (node == null)
            {
                return "";
            }

            string result = node.value.ToString() + " ";
            result += GetDisplayStringRecursive(node.next);
            return result;
        }

        // methods and features to add:
        // get current node reference DONE
        // insert node before first DONE
        // delete first node DONE
        // insert node after last DoNE
        // delete last node DONE
        // insert node after current - uses multiple methods DONE
        // delete current DONE
        // move current to next nodeDONE
        // move current to previous node DONE
        // recursive: find node with value - return reference or null DONE
        // recursive: get display string DONE
    }
    /*******************************
     * KD Feb2023 defines the double linked node
     * uses default T value
     ********************************/
    internal class DoubleLinkedListNode<T>
    {
        public T value;
        public DoubleLinkedListNode<T> next = null;
        public DoubleLinkedListNode<T> previous = null;

        public DoubleLinkedListNode(T value)
        {
            this.value = value;
            previous = null;
            next = null;
        }

        private DoubleLinkedListNode()
        {
            value = default(T);
        }
    }





}
